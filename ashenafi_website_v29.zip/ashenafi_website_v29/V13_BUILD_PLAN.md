# Ashenafi Website V13 — Visual Archive Editor

V13 connects the Media Vault to each Story, Memory, Journal, Timeline, Person, and Principle entry.

## Added
- Media attachment management from the content editor
- Photo/video upload directly into an entry
- Ordered media attachments
- Featured/cover media
- Captions and alt text
- Media metadata API
- Media detachment/deletion API
- Admin-only media management foundation

## Database
`Media` now stores `originalName`, `path`, `altText`, `sortOrder`, and `featured` in addition to the V12 fields.

After pulling the project, run `npx prisma generate` and create/apply a migration with your PostgreSQL database.

## Next V14
- Drag-and-drop media ordering
- Rich text editor
- Inline images inside story body
- Automatic thumbnails/transcoding
- Orphan-media cleanup
- S3-compatible private object storage + signed URLs
- Better audit events
