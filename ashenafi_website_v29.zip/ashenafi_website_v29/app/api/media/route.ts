import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { db } from "@/lib/db";
import fs from "fs/promises";
import path from "path";
import crypto from "crypto";
const MAX_BYTES = 100 * 1024 * 1024;
const ALLOWED = new Set(["image/jpeg","image/png","image/webp","image/gif","video/mp4","video/webm"]);
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "ADMIN") return NextResponse.json({error:"Unauthorized"},{status:401});
  const form = await req.formData(); const file = form.get("file"); const contentId = form.get("contentId")?.toString() || null;
  if (!(file instanceof File)) return NextResponse.json({error:"A file is required."},{status:400});
  if (!ALLOWED.has(file.type)) return NextResponse.json({error:"Unsupported file type."},{status:415});
  if (file.size > MAX_BYTES) return NextResponse.json({error:"File exceeds the 100 MB limit."},{status:413});
  if (contentId && !(await db.content.findUnique({where:{id:contentId}}))) return NextResponse.json({error:"Content not found."},{status:404});
  const bytes=Buffer.from(await file.arrayBuffer()); const ext=path.extname(file.name).toLowerCase() || ".bin";
  const safeName=`${crypto.randomUUID()}${ext}`; const dir=process.env.UPLOAD_DIR || path.join(process.cwd(),"uploads");
  await fs.mkdir(dir,{recursive:true}); await fs.writeFile(path.join(dir,safeName),bytes);
  const media=await db.media.create({data:{filename:safeName,originalName:file.name.slice(0,255),mimeType:file.type,size:file.size,path:path.join(dir,safeName),sortOrder: contentId ? await db.media.count({where:{contentId}}) : 0, ...(contentId?{contentId}:{})}});
  return NextResponse.json({media},{status:201});
}
