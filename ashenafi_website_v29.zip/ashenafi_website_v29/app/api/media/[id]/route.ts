import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { db } from "@/lib/db";
import fs from "fs/promises";
export async function GET(_req: NextRequest,{params}:{params:Promise<{id:string}>}) {
 const {id}=await params; const media=await db.media.findUnique({where:{id},include:{content:{include:{allowedViewers:true}}}});
 if(!media) return new NextResponse("Not found",{status:404}); const session=await getSession(); const c=media.content;
 if(c){
  if(c.visibility==="PRIVATE" && (!session || session.role!=="ADMIN")) return new NextResponse("Forbidden",{status:403});
  if(c.visibility==="FAMILY") { if(!session) return new NextResponse("Forbidden",{status:403}); if(session.role!=="ADMIN" && c.allowedViewers.length && !c.allowedViewers.some(v=>v.userId===session.userId)) return new NextResponse("Forbidden",{status:403}); }
 } else if(!session || session.role!=="ADMIN") return new NextResponse("Forbidden",{status:403});
 try { const data=await fs.readFile(media.path); return new NextResponse(data,{headers:{"Content-Type":media.mimeType,"Content-Length":String(data.length),"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff"}}); } catch { return new NextResponse("Media file unavailable",{status:404}); }
}
