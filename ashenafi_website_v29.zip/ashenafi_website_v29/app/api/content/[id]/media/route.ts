import {NextResponse} from "next/server";
import {db} from "@/lib/db";
import {requireAdmin} from "@/lib/auth";
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){const {id}=await params; await requireAdmin(); const media=await db.media.findMany({where:{contentId:id},orderBy:[{featured:"desc"},{sortOrder:"asc"},{createdAt:"asc"}]}); return NextResponse.json(media)}
