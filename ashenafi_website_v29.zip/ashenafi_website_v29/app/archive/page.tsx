import {db} from "@/lib/db";import ArchiveBrowser from "./ArchiveBrowser";
export default async function Archive(){const x=await db.content.findMany({where:{visibility:"PUBLIC",status:"PUBLISHED"},orderBy:{updatedAt:"desc"},include:{media:true}});return <main className="section"><ArchiveBrowser items={x}/></main>}
