import Link from "next/link";
export default function NotFound(){return <main className="section not-found"><div className="eyebrow">404 · LOST CHAPTER</div><h1 className="serif">This page hasn't been written yet.</h1><p className="lead">Some chapters are still waiting for their moment.</p><Link href="/" className="btn">Return home</Link></main>}
