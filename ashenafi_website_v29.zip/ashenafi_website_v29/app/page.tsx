import Link from "next/link";
import {db} from "@/lib/db";

export default async function Home(){
  const chapters=await db.content.findMany({where:{type:"STORY",visibility:"PUBLIC",status:"PUBLISHED"},orderBy:{createdAt:"asc"},take:3,include:{media:true}});
  const hero=chapters[0]?.media.find((m:any)=>m.featured)||chapters[0]?.media[0];
  return <main className="cinema-home">
    <section className="cinema-hero" style={hero?{backgroundImage:`linear-gradient(90deg,rgba(0,0,0,.78),rgba(0,0,0,.25)),url('/api/media/${hero.id}')`}:undefined}>
      <div className="hero-copy"><p className="eyebrow">A PERSONAL ARCHIVE · 2026 →</p><h1 className="cinema-title serif">ASHENAFI</h1><p className="cinema-subtitle">A life still being written.</p><p className="cinema-lead">Medical student. Dreamer. Son. Future physician. Builder.</p><Link className="btn cinema-enter" href="/story">ENTER MY STORY <span>↓</span></Link></div>
      <div className="scroll-cue">SCROLL TO BEGIN</div>
    </section>
    <section className="manifesto"><p className="eyebrow">THIS IS NOT A CV</p><h2 className="serif">It is the record of a life.</h2><p>Some days become memories. Some memories become lessons. Some lessons become principles. This archive is where they stay.</p></section>
    <section className="chapter-strip"><div><p className="eyebrow">THE CHAPTERS</p><h2 className="serif">A story in progress.</h2></div><div className="chapter-list">{chapters.map((c,i)=><Link href="/story" className="chapter-row" key={c.id}><span>0{i+1}</span><strong className="serif">{c.title}</strong><small>{c.excerpt||"A chapter waiting to be remembered."}</small><b>↗</b></Link>)}{!chapters.length&&<p className="muted">The first chapter is waiting to be written.</p>}</div></section>
    <section className="future-section"><p className="eyebrow">THE FUTURE</p><h2 className="serif">Physician · Family · Founder</h2><p>The personal story comes first. Beyond it is a larger dream: a life in medicine, a family legacy, and one day, Alembizu Memorial Hospital.</p><Link href="/story" className="text-link">Continue into the archive →</Link></section>
  </main>
}
