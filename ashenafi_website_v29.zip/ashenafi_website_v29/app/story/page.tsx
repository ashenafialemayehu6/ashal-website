import {db} from "@/lib/db";
import CinematicStory from "./CinematicStory";

export default async function Story(){
 const chapters=await db.content.findMany({where:{type:"STORY",visibility:"PUBLIC",status:"PUBLISHED"},orderBy:{createdAt:"asc"},include:{media:true}});
 return <main className="story-experience">
   <section className="story-intro"><p className="eyebrow">MY STORY</p><h1 className="serif">The chapters.</h1><p>Not a perfect story. A real one. Childhood, family, school, medicine, failures, victories, love, faith, ideas and the moments that changed direction.</p><p className="accessibility-note">Tip: use ↑ ↓ or ← → to move between chapters. Tap any photograph to enter fullscreen.</p></section>
   <CinematicStory chapters={chapters as any}/>
   {!chapters.length&&<div className="empty-story"><p className="eyebrow">NOT YET WRITTEN</p><h2 className="serif">The first chapter is waiting.</h2></div>}
   <section className="story-ending"><p className="eyebrow">TO BE CONTINUED</p><h2 className="serif">The story is still being written.</h2><p>There are chapters that belong to childhood, chapters that belong to today, and chapters that have not happened yet.</p></section>
 </main>
}
