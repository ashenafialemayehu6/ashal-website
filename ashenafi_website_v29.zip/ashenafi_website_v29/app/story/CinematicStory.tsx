"use client";
import {useEffect,useMemo,useState} from "react";

type Media={id:string;mimeType:string;caption?:string|null;altText?:string|null;featured?:boolean};
type Block={id:string;type:string;data:any};
type Chapter={id:string;title:string;excerpt?:string|null;body:string;media:Media[]};

export default function CinematicStory({chapters}:{chapters:Chapter[]}){
 const [active,setActive]=useState(0); const [lightbox,setLightbox]=useState<string|null>(null);
 const ids=useMemo(()=>chapters.map(c=>`chapter-${c.id}`),[chapters]);
 useEffect(()=>{const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){const n=ids.indexOf(e.target.id);if(n>=0)setActive(n)}}),{rootMargin:"-25% 0px -60% 0px"});ids.forEach(id=>{const el=document.getElementById(id);if(el)obs.observe(el)});return()=>obs.disconnect()},[ids]);
 useEffect(()=>{const f=(e:KeyboardEvent)=>{if(e.key==="Escape")setLightbox(null);if(!lightbox&&(e.key==="ArrowDown"||e.key==="ArrowRight")){document.getElementById(ids[Math.min(active+1,ids.length-1)])?.scrollIntoView({behavior:"smooth"})}if(!lightbox&&(e.key==="ArrowUp"||e.key==="ArrowLeft")){document.getElementById(ids[Math.max(active-1,0)])?.scrollIntoView({behavior:"smooth"})}};window.addEventListener("keydown",f);return()=>window.removeEventListener("keydown",f)},[active,ids,lightbox]);
 return <>
   <div className="story-progress"><div style={{width:`${chapters.length?((active+1)/chapters.length)*100:0}%`}}/></div>
   {chapters.length>1&&<nav className="chapter-dock" aria-label="Chapter navigation">{chapters.map((c,i)=><button key={c.id} className={i===active?"active":""} onClick={()=>document.getElementById(ids[i])?.scrollIntoView({behavior:"smooth"})}><span>{String(i+1).padStart(2,"0")}</span><b>{c.title}</b></button>)}</nav>}
   {chapters.map((c,index)=><article className="cinema-chapter" id={`chapter-${c.id}`} key={c.id}>
      <div className="chapter-number">CHAPTER {String(index+1).padStart(2,"0")} · {String(chapters.length).padStart(2,"0")}</div><h2 className="serif">{c.title}</h2>{c.excerpt&&<p className="chapter-excerpt">{c.excerpt}</p>}
      <div className="chapter-content"><Render blocks={parse(c.body)} media={c.media} openLightbox={setLightbox}/></div>
      <div className="chapter-nav"><button disabled={index===0} onClick={()=>document.getElementById(ids[index-1])?.scrollIntoView({behavior:"smooth"})}>← Previous</button><span>{index+1} / {chapters.length}</span><button disabled={index===chapters.length-1} onClick={()=>document.getElementById(ids[index+1])?.scrollIntoView({behavior:"smooth"})}>Next →</button></div>
   </article>)}
   {lightbox&&<div className="lightbox" role="dialog" aria-modal="true" onClick={()=>setLightbox(null)}><button className="lightbox-close" aria-label="Close">×</button><img src={`/api/media/${lightbox}`} alt="" onClick={e=>e.stopPropagation()}/></div>}
 </>
}
function parse(body:string):Block[]{try{const x=JSON.parse(body);if(Array.isArray(x)&&x.every((b:any)=>b?.type&&b?.data))return x}catch{}return [{id:"legacy",type:"TEXT",data:{text:body}}]}
function Render({blocks,media,openLightbox}:{blocks:Block[];media:Media[];openLightbox:(id:string)=>void}){const find=(id:string)=>media.find(x=>x.id===id);return <>{blocks.map(b=>{if(b.type==="TEXT")return <div className="story-copy" key={b.id}>{String(b.data.text||"").split(/\n\s*\n/).filter(Boolean).map((p,j)=><p key={j}>{p}</p>)}</div>;if(b.type==="IMAGE"){const m=find(b.data.mediaId);return m?<figure className="cinema-figure interactive-figure" key={b.id}><button onClick={()=>openLightbox(m.id)}><img src={`/api/media/${m.id}`} alt={m.altText||""}/></button>{m.caption&&<figcaption>{m.caption}</figcaption>}</figure>:null}if(b.type==="VIDEO"){const m=find(b.data.mediaId);return m?<figure className="cinema-figure" key={b.id}><video src={`/api/media/${m.id}`} controls preload="metadata"/>{m.caption&&<figcaption>{m.caption}</figcaption>}</figure>:null}if(b.type==="QUOTE")return <blockquote className="story-quote" key={b.id}>“{b.data.text}”{b.data.attribution&&<cite>— {b.data.attribution}</cite>}</blockquote>;if(b.type==="GALLERY")return <div className="story-gallery cinema-gallery" key={b.id}>{(b.data.mediaIds||[]).map((id:string)=>{const m=find(id);return m?<button key={id} onClick={()=>openLightbox(id)}><img src={`/api/media/${id}`} alt={m.altText||""}/></button>:null})}</div>;if(b.type==="TIMELINE")return <div className="story-timeline" key={b.id}><span>{b.data.date}</span><h3>{b.data.title}</h3><p>{b.data.text}</p></div>;return <hr key={b.id}/>})}</>}
