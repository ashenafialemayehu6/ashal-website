# Ashenafi Website V17 — Visual Storytelling Studio

V17 upgrades the V16 block editor into a more usable visual authoring studio.

## Added
- Drag-and-drop reordering of story blocks.
- Drag-and-drop reordering of media cards.
- Visual canvas with focused block state and drag handles.
- Lightweight inline Markdown formatting for text blocks: bold, italic, links and quote prefix.
- Safe preview rendering for supported inline Markdown (HTML is escaped before formatting).
- Media usage counts showing how many times each media item is used in the current story.
- Deleting media automatically removes references from the current editor state.
- Improved upload control and studio status bar.
- Existing draft recovery, version history, privacy, media access controls and block types remain compatible.

## Block model
TEXT, IMAGE, VIDEO, QUOTE, GALLERY, TIMELINE, DIVIDER.

## Important production notes
- This is still an autobiographical/content platform, not a medical-record system.
- Before production, add object storage/CDN, malware scanning, image metadata stripping, video transcoding, thumbnails/poster generation, quotas/rate limits and backups.
- For public rendering, move rich text to a server-side sanitizer or structured rich-text AST if more formatting is added.
- Media deletion should eventually use an explicit confirmation workflow and orphan-media report before permanent deletion.
