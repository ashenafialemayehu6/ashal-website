# Ashenafi Website V16 — Block Storytelling System

V16 replaces the V15 inline-media token workflow with a structured block editor while keeping the existing PostgreSQL Content model. Blocks are serialized as JSON inside `Content.body`, so no Prisma migration is required.

## Block types
- TEXT — narrative paragraphs
- IMAGE — one reusable media item
- VIDEO — one reusable video
- QUOTE — highlighted thought with optional attribution
- GALLERY — multiple reusable images
- TIMELINE — date + moment + reflection
- DIVIDER — cinematic pause

## Editor
- Add, duplicate, delete and move blocks
- Select media from the attached Media Vault
- Drag/reorder media in the vault
- Captions, alt text and cover media remain supported
- Seven-day local draft recovery
- Preview the assembled story before publishing
- Existing version history and restore remain supported

## Rendering
Public Story now understands structured blocks and renders galleries, quotes and timeline moments. Legacy V1–V15 text/token bodies still render as a single text block, so existing content is not lost.

## Security
Media continues to be served through the existing visibility-aware `/api/media/[id]` route. Production must use private object storage and short-lived signed URLs rather than local filesystem storage.

## Next direction: V17
- Drag-and-drop canvas interaction rather than buttons
- Rich text marks inside TEXT blocks with sanitization
- Gallery lightbox and fullscreen cinematic viewer
- Responsive media focal points/crop settings
- Automatic thumbnails and video poster frames
- Media usage index + orphan cleanup
- Autosave status indicator and publish workflow
