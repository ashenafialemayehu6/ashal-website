# V19 — Archive & Navigation Experience

V19 builds on V18 and focuses on the public reading/archive experience.

## Added
- Fixed chapter progress indicator.
- Chapter navigation dock on desktop.
- Previous/next chapter controls.
- Keyboard chapter navigation with arrow keys.
- Fullscreen image lightbox with Escape close.
- Clickable gallery/image media.
- Public archive type filtering.
- Archive media thumbnails.
- Responsive mobile behavior.
- Reduced-motion-friendly transitions via existing simple CSS (production follow-up should add prefers-reduced-motion overrides).

## Production follow-up
- Add canonical URLs and OpenGraph/Twitter metadata per chapter.
- Add sitemap/robots and structured data.
- Move private media to signed object-storage URLs.
- Add real image thumbnails/srcset and modern formats.
- Add a dedicated public Memory detail route with stable slugs.
- Add `prefers-reduced-motion` CSS and focus-trap behavior for lightbox.
