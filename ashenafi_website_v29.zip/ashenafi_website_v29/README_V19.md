# Ashenafi Website V19

V19 focuses on the public archive and cinematic navigation experience. It preserves the V18 database/auth/content architecture while adding chapter progress/navigation, keyboard movement, fullscreen image viewing, and archive filtering.

## Run
npm install
cp .env.example .env
npx prisma generate
npm run dev

## Note
This is still a development/personal-archive foundation. Do not store medical records or sensitive patient data here until a separate production-grade clinical system is designed and audited.
