# Ashenafi Website V29 — Final Experience Polish

V29 consolidates the personal archive experience with accessibility, responsive navigation, public archive search, metadata, and graceful 404 handling.

## New
- Accessible skip link and keyboard focus treatment.
- Responsive mobile navigation.
- Global public search over published PUBLIC content.
- Reduced-motion support.
- Improved semantic footer and page metadata.
- Custom 404 “lost chapter” experience.

## Privacy
Search only queries PUBLIC + PUBLISHED content. Family/private content is never included.

## Production checklist
Before launch: PostgreSQL production database, private object storage with signed URLs, HTTPS, backups, rate limiting, secure secrets, monitoring, image/video optimization, malware scanning, account recovery, audit review, and legal/privacy review.

## Content workflow
Keep placeholders until Ashenafi is ready to fill the archive gradually. Do not put sensitive personal or medical records into the public archive.
