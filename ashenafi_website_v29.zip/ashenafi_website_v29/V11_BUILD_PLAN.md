# V11

Completed: content editing; version snapshots; version history; restore; family accounts; per-content family permissions; visibility controls; admin library; family dashboard; audit foundation.

V12 candidates: private media gallery, signed URLs, invitations, password reset, MFA, rich timeline, drag/drop story sections, galleries, autosave, search/tags, audit viewer, export/backup.