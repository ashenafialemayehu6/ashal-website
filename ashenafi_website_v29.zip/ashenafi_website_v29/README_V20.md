# Ashenafi Website V20

V20 continues V19 with the Identity & Personalization Layer.

New public routes:
- `/about` — Who Is Ashenafi?
- `/people` — public people archive
- `/timeline` — public life timeline

The existing V11–V19 architecture is preserved. Public content is read from the existing Prisma Content model, filtered to PUBLIC + PUBLISHED.
