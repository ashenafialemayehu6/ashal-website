import {cookies} from "next/headers";
import {jwtVerify,SignJWT} from "jose";
import {db} from "./db";
const secret=new TextEncoder().encode(process.env.AUTH_SECRET||"development-only-secret-change-me");
export type Session={userId:string;role:"ADMIN"|"FAMILY"};
export async function createSession(s:Session){const token=await new SignJWT(s).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("7d").sign(secret);(await cookies()).set("legacy_session",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",path:"/",maxAge:604800});}
export async function getSession():Promise<Session|null>{const token=(await cookies()).get("legacy_session")?.value;if(!token)return null;try{const {payload}=await jwtVerify(token,secret);if(typeof payload.userId!=="string"||(payload.role!=="ADMIN"&&payload.role!=="FAMILY"))return null;const u=await db.user.findUnique({where:{id:payload.userId}});return u?{userId:u.id,role:u.role}:null}catch{return null}}
export async function requireAdmin(){const s=await getSession();if(!s||s.role!=="ADMIN")throw new Error("ADMIN_REQUIRED");return s}
export async function logout(){(await cookies()).delete("legacy_session")}