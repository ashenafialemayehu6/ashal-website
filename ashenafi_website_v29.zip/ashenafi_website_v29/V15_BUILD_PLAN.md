# Ashenafi Website V15 — Visual Storytelling Editor

V15 turns the writing editor into a lightweight visual-storytelling system.

## Added
- Inline image blocks using `:::image MEDIA_ID:::` tokens.
- Inline video blocks using `:::video MEDIA_ID:::` tokens.
- One-click Insert action from the attached media library.
- Public Story renderer that turns those tokens into responsive media figures.
- Existing media ordering, captions, alt text, cover image, version history, draft recovery, and access control remain intact.

## How to use
1. Create/save a story.
2. Upload photos/videos in the Visual Story Blocks section.
3. Put the cursor in the text where the visual should appear.
4. Click **Insert** on that media item.
5. Save/publish.

## Security notes
Media is still served through `/api/media/[id]`, which checks the content visibility and session before serving the file. Production should move local files to private object storage with short-lived signed URLs.

## V16 direction
- Rich block model instead of text tokens.
- Drag-and-drop blocks (text/image/video/quote/gallery/timeline).
- True Markdown/HTML preview rendering with sanitization.
- Automatic thumbnails/transcoding.
- Gallery/lightbox and cinematic transitions.
- Media usage/orphan tracking.
