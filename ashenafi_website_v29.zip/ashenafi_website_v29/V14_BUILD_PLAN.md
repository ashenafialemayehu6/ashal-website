# Ashenafi Website V14

V14 turns the content editor into a more practical personal-archive writing studio.

## Added
- Lightweight markdown-style writing toolbar: bold, italic, heading, quote, list, link.
- Edit/preview mode.
- Live word and character counts.
- Local draft autosave for existing entries (7-day recovery window).
- Clear local draft control.
- HTML5 drag-and-drop media reordering with persisted sort order.
- Cover/featured-media selection.
- Caption and alt-text editing.
- Media deletion from the editor.

## Safety / architecture notes
- Existing role and visibility checks remain in place.
- Media files are still served through the protected media route.
- This is a personal-archive CMS foundation, not a production medical-record system.
- Before public deployment: move uploads to private object storage, use short-lived signed URLs, add malware scanning/transcoding/thumbnails, backups, rate limits, CSRF/origin protections where applicable, stronger validation, and monitoring.

## Next milestone: V15
- Real rich-text document model instead of lightweight markdown syntax.
- Inline media blocks and cover selection in published pages.
- Search/filter media library.
- Media collections and tags.
- Orphan-media cleanup and storage accounting.
- Better mobile editor UX.
