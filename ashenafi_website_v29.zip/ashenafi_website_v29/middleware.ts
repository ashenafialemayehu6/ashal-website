import {NextResponse} from "next/server";import type {NextRequest} from "next/server";
export function middleware(r:NextRequest){if(r.nextUrl.pathname.startsWith("/admin")&&!r.cookies.get("legacy_session")?.value)return NextResponse.redirect(new URL("/login",r.url));return NextResponse.next()}
export const config={matcher:["/admin/:path*"]};