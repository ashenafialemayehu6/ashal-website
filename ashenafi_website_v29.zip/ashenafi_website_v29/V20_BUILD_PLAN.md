# V20 — Identity & Personalization Layer

V20 adds the public identity layer around the cinematic archive: About/Who Is Ashenafi, People, and Timeline pages, plus expanded global navigation. It uses the existing public Content types so no destructive database migration is required.

## Direction
The site now has three layers: cinematic home/story, archive/navigation, and identity/timeline context. Personal placeholders are intentionally short so Ashenafi can replace them gradually.

## Next
V21 should add richer public profile data, editable site settings, family/relationship chapter gates, SEO metadata, Open Graph images, and a proper legacy/future landing page.
