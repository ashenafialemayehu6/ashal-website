# Ashenafi Website V18 — Cinematic Public Experience

V18 shifts the public-facing site from a CMS-like presentation into a cinematic autobiography experience.

## Added
- Full-screen homepage hero with featured public media when available
- Editorial manifesto section
- Chapter strip and future/legacy section
- Cinematic Story landing page
- Chapter numbering and long-form presentation
- Large immersive media treatment
- Mobile-responsive public experience
- Existing V17 block schema remains compatible

## Architecture note
V18 does not change the database schema. Existing Story blocks remain the source of truth, while the public renderer provides a distinct visual layer.

## Next
V19 can add chapter navigation/progress, smooth scroll transitions, a true timeline page, public memory gallery, lightbox, keyboard accessibility, reduced-motion handling, and richer metadata/SEO.
