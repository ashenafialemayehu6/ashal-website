# Ashenafi Legacy Website — V13

V13 adds editing, version history/restore, family accounts, per-content family permissions, public/family/private visibility, admin content management, a family dashboard, and an audit-log foundation.

Run:
1. Copy `.env.example` to `.env`.
2. Set `DATABASE_URL` and a strong `AUTH_SECRET`.
3. `npm install`
4. `npx prisma migrate dev --name init`
5. `npm run db:seed`
6. `npm run dev`

Seed admin: `admin@example.com` / `change-this-password`. Change it immediately.

Privacy:
- PUBLIC: published public content.
- FAMILY: authenticated family content; if viewers are assigned, only those family accounts.
- PRIVATE: admin only.

Production still needs private object storage/signed media URLs, MFA, password recovery, rate limiting, backups, monitoring, and legal/privacy review. Keep the personal archive separate from any future clinical platform.
## V18
V18 introduces the cinematic public experience while preserving the V17 block editor and database schema. See `V18_BUILD_PLAN.md`.
